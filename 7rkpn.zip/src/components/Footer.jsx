import React from "react";

function Footer() {
  return (
    <div className="footer">
      <p>© Al PAthfinder Team. All rights reserved.</p>
    </div>
  );
}

export default Footer;
