import React from "react";

function Home() {
  return <div>Home Page</div>;
}

export default Home;
