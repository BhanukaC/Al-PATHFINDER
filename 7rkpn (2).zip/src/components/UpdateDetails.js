import React, { useRef, useState } from "react";
import { Form, Button, Card, Alert } from "react-bootstrap";
import { useAuth } from "../context/AuthContext";
import { Link, useHistory } from "react-router-dom";
import "firebase/firestore";
import firebase, { auth } from "../firebase";

export default function UpdateDetails() {
  const { currentUser, updatePassword } = useAuth();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const history = useHistory();

  function handleSubmit(e) {
    e.preventDefault();

    async function getData(role, email) {
      const db = firebase.firestore();
      await db
        .collection(role)
        .doc(email)
        .get()
        .then((doc) => {
          if (doc.exists) {
            localStorage.setItem("role", role);
            setData(doc.data());
          } else {
            console.log("not found");
          }
        })
        .catch((error) => {
          console.log("Error getting document:", error);
        });
    }
  }

  return (
    <>
      <Card>
        <Card.Body>
          <h2 className="text-center mb-4">Update Details</h2>
          {error && <Alert variant="danger">{error}</Alert>}
          <Form onSubmit={handleSubmit}>
            <Form.Group id="Name">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="email"
                ref={emailRef}
                required
                defaultValue={currentUser.email}
              />
            </Form.Group>
            <Button disabled={loading} className="w-100" type="submit">
              Update
            </Button>
          </Form>
        </Card.Body>
      </Card>
      <div className="w-100 text-center mt-2">
        <Link to="/dashboard">Cancel</Link>
      </div>
    </>
  );
}
