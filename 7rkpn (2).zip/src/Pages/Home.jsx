import React from "react";
import "./Home.css";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div>
      <div className="container main-container">
        <div className="row">
          <div className="col-md-6">
            <img className="img-fluid" src={require("./../assets/icon2.png")} />
          </div>
          <div className="col-md-6">
            <h1 className="display-3 my-header">Where EDUCATION happens</h1>
            <div className="my-page-header mt-6">
              <h2 className="page-header">
                <small>
                  Are you a <b>STUDENT</b> or a{" "}
                  <b>TEACHER? You have come to the right place</b>
                </small>
                ?
              </h2>
              <div className="row">
                <div className="col-md-3 mx-3 mt-3 text-center">
                  <Link to="/login">
                    <img
                      className="img-fluid  my-box"
                      src={require("./../assets/student.png")}
                      alt="student"
                      height="100"
                      width="100"
                    />
                  </Link>
                  <p>
                    <b> I'm a student</b>
                  </p>
                </div>
                <div className="col-md-3 mx-3 mt-3 text-center">
                  <Link to="/login">
                    <img
                      className="img-fluid  my-box"
                      src={require("./../assets/teacher.png")}
                      alt="student"
                      height="100"
                      width="100"
                    />
                  </Link>
                  <p>
                    <b>I'm a teacher</b>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <div>
          <p className="text-center">
            <b>OUR PARTNERS</b>
          </p>
        </div>
        <div className="row bt">
          <div className="col-md-2 text-center">
            <img
              className="img-fluid"
              src={require("./../assets/img1.png")}
              alt="partners"
              width="100px"
              height="100px"
            />
          </div>
          <div className="col-md-2 text-center">
            <img
              class="img-fluid"
              src={require("./../assets/img2.png")}
              alt="partners"
              width="100px"
              height="100px"
            />
          </div>
          <div class="col-md-2 text-center">
            <img
              className="img-fluid"
              src={require("./../assets/img3.png")}
              alt="partners"
              width="100px"
              height="100px"
            />
          </div>
          <div class="col-md-2 text-center">
            <img
              className="img-fluid"
              src={require("./../assets/img4.png")}
              alt="partners"
              width="100px"
              height="100px"
            />
          </div>
          <div className="col-md-2 text-center">
            <img
              class="img-fluid"
              src={require("./../assets/img5.png")}
              alt="partners"
              width="100px"
              height="100px"
            />
          </div>
          <div className="col-md-2 text-center">
            <img
              class="img-fluid"
              src={require("./../assets/img6.png")}
              alt="partners"
              width="100px"
              height="100px"
            />
          </div>
        </div>
        <hr />
      </div>
    </div>
  );
}

export default Home;
