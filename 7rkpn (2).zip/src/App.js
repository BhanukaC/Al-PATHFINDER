import "./styles.css";
import NavBar from "./components/NavBar";
import About from "./Pages/About";
import Home from "./Pages/Home";
import Signup from "./components/Signup";
import LoginPage from "./Pages/LoginPage";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Footer from "./components/Footer";

export default function App() {
  return (
    <Router>
      <div className="App">
        <NavBar />
        <Switch>
          <Route path="/" exact component={Home}></Route>
          <Route path="/about" exact component={About}></Route>
          <Route path="/login" exact component={LoginPage}></Route>
        </Switch>
        <Footer />
      </div>
    </Router>
  );
}
